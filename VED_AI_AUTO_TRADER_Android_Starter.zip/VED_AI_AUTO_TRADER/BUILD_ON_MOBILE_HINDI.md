# मोबाइल से APK बनाना (GitHub Actions)

1. ZIP को फोन में डाउनलोड करें और Extract करें।
2. github.com पर GitHub account बनाएं/लॉगिन करें।
3. New repository बनाएं, नाम `VED-AI-AUTO-TRADER` रखें और Public या Private चुनें।
4. फोन के ब्राउज़र में repository खोलें → Add file → Upload files. Extract किए गए प्रोजेक्ट की सभी फाइलें/फ़ोल्डर अपलोड करें। `.github/workflows/android.yml` सहित hidden `.github` folder भी शामिल होना चाहिए। Commit changes करें।
5. Repository में Actions टैब खोलें → `Build VED Android APK` चुनें → Run workflow दबाएं।
6. Build सफल होने पर workflow run खोलें और Artifacts में `VED-AI-AUTO-TRADER-debug-apk` डाउनलोड करें। ZIP artifact को Extract करें; `app-debug.apk` इंस्टॉल करें।

अगर GitHub मोबाइल UI hidden `.github` फ़ोल्डर अपलोड न करे, तो GitHub वेबसाइट को Chrome में Desktop site मोड में खोलें या repository में workflow फ़ाइल अलग से बनाएं।

यह debug/demo APK है। इसमें Gmail login, Groww/Delta API और live order execution अभी implemented नहीं हैं। Live trading के लिए सुरक्षित backend, broker authorization, risk controls, testing और लागू नियमों का पालन आवश्यक है।
