package com.ved.autotrader

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF101820)
private val Gold = Color(0xFFF3C65E)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VedApp() }
    }
}

@Composable
fun VedApp() {
    var demoOn by remember { mutableStateOf(false) }
    var selectedBroker by remember { mutableStateOf("Both brokers") }
    var selectedMarket by remember { mutableStateOf("NIFTY / BANKNIFTY") }
    var risk by remember { mutableStateOf("1% per trade (₹50)") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, background = Navy, surface = Color(0xFF1C2A33)
    )) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("VED", color = Gold, fontSize = 34.sp, fontWeight = FontWeight.Black)
                Text("AI AUTO TRADER", color = Color.White, fontSize = 13.sp, letterSpacing = 3.sp)
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1C2A33))) {
                    Column(Modifier.fillMaxWidth().padding(18.dp)) {
                        Text("DEMO WALLET", color = Color.LightGray, fontSize = 12.sp)
                        Text("₹5,000.00", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Text("Live funds are not connected", color = Gold, fontSize = 12.sp)
                    }
                }
                Text("TRADING CONTROLS", color = Gold, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("Paper trading", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("No real orders will be sent", color = Color.LightGray, fontSize = 12.sp)
                    }
                    Switch(checked = demoOn, onCheckedChange = { demoOn = it })
                }
                StatusRow("Entry", "Strategy placeholder")
                StatusRow("Stop Loss", "Risk rule placeholder")
                StatusRow("Target / Exit", "Exit rule placeholder")
                Divider(color = Color.DarkGray)
                Text("SETTINGS", color = Gold, fontWeight = FontWeight.Bold)
                SettingDropdown("Broker", selectedBroker, listOf("Both brokers", "Groww", "Delta Exchange")) { selectedBroker = it }
                SettingDropdown("Market", selectedMarket, listOf("NIFTY / BANKNIFTY", "Delta crypto derivatives")) { selectedMarket = it }
                SettingDropdown("Risk limit", risk, listOf("1% per trade (₹50)", "0.5% per trade (₹25)", "2% per trade (₹100)")) { risk = it }
                OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) {
                    Text("Gmail sign-in — setup required")
                }
                Text(
                    "BROKER STATUS: NOT CONNECTED\nLive trading is disabled in this starter build. Broker OAuth/API, server-side secrets, order reconciliation, exchange compliance and tested risk controls must be completed before live orders.",
                    color = Color(0xFFFFD9A0), fontSize = 12.sp, lineHeight = 18.sp
                )
                Text("VED v0.1 • Demo interface", color = Color.Gray, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun StatusRow(title: String, detail: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
        Text(detail, color = Color.LightGray, fontSize = 12.sp)
    }
}

@Composable
private fun SettingDropdown(
    label: String, value: String, options: List<String>, onSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Column {
        Text(label, color = Color.LightGray, fontSize = 12.sp)
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                Text(value, modifier = Modifier.weight(1f))
                Text("⌄")
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                options.forEach { option ->
                    DropdownMenuItem(text = { Text(option) }, onClick = {
                        onSelected(option); expanded = false
                    })
                }
            }
        }
    }
}
